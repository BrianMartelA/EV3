$(document).ready(function(){
    $("#Cambiar").click(function(){
       
   })});




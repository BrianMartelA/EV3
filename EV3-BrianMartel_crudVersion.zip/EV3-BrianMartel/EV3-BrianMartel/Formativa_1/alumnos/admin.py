from django.contrib import admin
from .models import Productos, cliente,Registro_cliente

# Register your models here.
admin.site.register(cliente)
admin.site.register(Registro_cliente)
admin.site.register(Productos)
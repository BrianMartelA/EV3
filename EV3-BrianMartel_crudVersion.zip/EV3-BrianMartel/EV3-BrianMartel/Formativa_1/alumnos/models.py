from django.db import models
from django.contrib.auth.models import User

# Create your models here.

class cliente(models.Model):
    user = models.CharField(primary_key=True,max_length =10)
    password = models.CharField(blank=False, null=False, max_length=20)
    confirmpassword =models.CharField(blank=False, null=False, max_length=20, default='ExamplePassword')
    mail = models.CharField(blank=False, null=False, max_length=20)
    confirmmail = models.CharField(blank=False, null=False, max_length=20, default='default@example.com')
    def __str__(self):
        return self.user
    
class Registro_cliente(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE,default="")
    def __str__(self):
        return self.user.username
    
class Categoria(models.Model):
    id_categoria = models.IntegerField(primary_key=True, verbose_name="Id categoria")
    nombreCategoria = models.CharField(max_length=80, blank=True, verbose_name="Nombre categoria")
    def __str__(self):
        return self.nombreCategoria

class Productos(models.Model):
    nombre = models.CharField(max_length=200)
    id = models.CharField(primary_key=True, max_length=7)
    description = models.CharField(max_length=500)
    price = models.IntegerField()
    stock = models.IntegerField()
    image = models.ImageField()
    categoria= models.ForeignKey(Categoria, on_delete=models.CASCADE, verbose_name="Categoria")
    def __str__(self):
        return self.nombre
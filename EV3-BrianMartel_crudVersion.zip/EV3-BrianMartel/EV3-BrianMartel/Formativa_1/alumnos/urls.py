from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('index',views.index,name='index'),
    path('galeria',views.galeria,name='galeria'),
    path('contacto',views.contacto,name='contacto'),
    path('quienes_somos',views.quienes_somos,name='quienes_somos'),
    path('boulder',views.boulder,name='boulder'),
    path('registro',views.registro,name='registro'),
    path('perfil',views.perfil, name='perfil'),
    path('product/manage/',views.products_manage, name='product_manage'),
    path('product/add/',views.product_add, name='product_add'),
    path('product/edit/<int:pk>/',views.product_edit, name='product_edit'),
    path('product/delete/<int:pk>/',views.product_delete, name='product_delete'),
    path('test', views.test, name='test')
]
